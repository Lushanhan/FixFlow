"""
新闻搜索模块
===========
根据标签编码筛选数据库中的新闻。
前端输入标签编码列表（None 为通配），
匹配唯一标识中对应编码的新闻并返回。

搜索规则：
  - 输入中的 None 值被忽略（视为通配，不做筛选）
  - 非 None 的编码必须全部存在于新闻的唯一标识的标签后缀中
  - 不关注编码的位置和排序
  - 返回结果格式与数据库存储格式一致
"""

import logging
from typing import List, Optional

from sqlalchemy.orm import Session

from .models import News

logger = logging.getLogger("search")


def parse_label_codes(label: str) -> set:
    """
    解析唯一标识，提取所有标签编码（日期之后的部分）
    -----------------------------------------------
    示例:
        label = "1001_2026.7.7_A_03_04_10"
        → {"A", "03", "04", "10"}

    参数:
        label: 唯一标识字符串
    返回:
        标签编码集合
    """
    if not label:
        return set()
    parts = label.split("_")
    # 格式: {大学编码}_{日期编码}_{来源标签}_{LLM标签...}
    # parts[0] = 大学编码, parts[1] = 日期编码
    # parts[2:] = 所有标签编码
    if len(parts) <= 2:
        return set()
    return set(parts[2:])


def search_news(
    db: Session,
    codes: List[Optional[str]],
) -> List[dict]:
    """
    根据标签编码筛选新闻
    --------------------
    参数:
        db:    数据库会话
        codes: 标签编码列表，如 ["A", "03", None, "10"]
               None 表示该位置不做筛选

    返回:
        匹配的新闻列表，每项为字典，格式与数据库存储一致
        包含字段: id, title, content, summary, label, source,
                  source_url, author, publish_time, view_count

    搜索逻辑:
        输入 ["A", "03", None, "10"]
        → 非None编码: {"A", "03", "10"}
        → 某新闻 label = "1001_2026.7.7_A_03_04_10"
        → 标签编码集: {"A", "03", "04", "10"}
        → {"A", "03", "10"} ⊆ {"A", "03", "04", "10"} → 匹配 ✓
    """
    # ----- 提取非 None 的筛选编码 -----
    required_codes = {c for c in codes if c is not None}
    logger.info(f"搜索条件（非None编码）: {required_codes}")

    if not required_codes:
        # 全部为 None，返回所有已发布新闻
        logger.info("无筛选条件，返回全部已发布新闻")
        all_news = db.query(News).filter(News.is_published == True).all()
        return [_news_to_dict(n) for n in all_news]

    # ----- 遍历已发布新闻，逐个匹配 -----
    results = []
    all_published = db.query(News).filter(News.is_published == True).all()

    for news in all_published:
        label_codes = parse_label_codes(news.label)
        # 检查非 None 编码是否全部存在于 label 中
        if required_codes.issubset(label_codes):
            results.append(_news_to_dict(news))

    logger.info(f"搜索结果: 匹配 {len(results)} 条新闻（共 {len(all_published)} 条已发布）")
    return results


def _news_to_dict(news: News) -> dict:
    """
    将 News 对象转换为字典
    ----------------------
    返回格式与数据库存储字段保持一致。
    """
    return {
        "id": news.id,
        "title": news.title,
        "content": news.content,
        "summary": news.summary,
        "label": news.label,
        "source": news.source,
        "source_url": news.source_url,
        "author": news.author,
        "publish_time": news.publish_time.isoformat() if news.publish_time else None,
        "created_at": news.created_at.isoformat() if news.created_at else None,
        "updated_at": news.updated_at.isoformat() if news.updated_at else None,
        "view_count": news.view_count,
        "is_published": news.is_published,
    }
