"""
FastAPI 应用入口
===============
校园新闻展示网站的后端服务入口。
通过 uvicorn 启动：uvicorn app.main:app --reload
启动后访问 http://localhost:8000/docs 查看自动生成的 API 文档。
"""

from contextlib import asynccontextmanager
from typing import List, Optional

from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session

from .database import get_db
from .init_db import init_database
from .search import search_news


# ============================================================
# 应用生命周期管理
# 使用 lifespan 上下文管理器处理启动和关闭时的操作
# ============================================================
@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    FastAPI 应用生命周期管理
    -------------------------
    启动时：
        - 初始化数据库（建表 + 种子数据）
    关闭时：
        - 预留清理逻辑
    """
    # ----- 应用启动时执行 -----
    print("正在初始化数据库...")
    init_database()
    print("数据库初始化完成。")

    yield  # 应用运行期间

    # ----- 应用关闭时执行 -----
    print("应用关闭。")


# ============================================================
# 创建 FastAPI 应用实例
# ============================================================
app = FastAPI(
    title="校园新闻展示平台",
    description="收集并展示校园新闻的后端 API 服务",
    version="0.1.0",
    lifespan=lifespan,
)


# ============================================================
# 基础路由
# ============================================================

@app.get("/", tags=["基础"])
def root():
    """
    根路径 —— 健康检查
    ------------------
    返回应用基本状态信息，用于确认服务是否正常运行。
    """
    return {
        "message": "校园新闻展示平台 API 服务运行中",
        "version": "0.1.0",
        "status": "ok",
    }


# ============================================================
# 新闻搜索路由
# ============================================================

@app.post("/news/search", tags=["新闻搜索"])
def search_news_by_codes(
    codes: List[Optional[str]],
    db: Session = Depends(get_db),
):
    """
    按标签编码筛选新闻
    ------------------
    前端传入标签编码列表，None 表示该位不做筛选。
    匹配唯一标识中日期编码后的标签部分，不关注位置和排序。

    请求示例:
        POST /news/search
        Body: ["A", "03", null, "10"]

    匹配逻辑:
        输入非None编码: {"A", "03", "10"}
        新闻label: "1001_2026.7.7_A_03_04_10"
        → 标签集: {"A", "03", "04", "10"}
        → {"A", "03", "10"} ⊆ {"A", "03", "04", "10"} → 匹配 ✓

    返回:
        匹配的新闻列表，格式与数据库存储一致
    """
    results = search_news(db, codes)
    return {
        "count": len(results),
        "results": results,
    }

