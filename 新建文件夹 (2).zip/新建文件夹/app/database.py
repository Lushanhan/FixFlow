"""
数据库连接与会话管理模块
=======================
本模块是后端访问数据库的唯一入口，前端或其他外部服务无法直接接触数据库。
- engine: SQLAlchemy 引擎，负责与 SQLite 数据库文件通信
- SessionLocal: 会话工厂，每个请求通过它获取独立的数据库会话
- Base: 所有数据模型的基类，用于统一管理表结构
- get_db: FastAPI 依赖注入函数，提供请求级别的数据库会话
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# ============================================================
# 数据库文件路径：项目根目录下的 campus_news.db
# SQLite 连接配置：check_same_thread=False 允许 FastAPI
# 多线程环境下正常使用 SQLite
# ============================================================
SQLALCHEMY_DATABASE_URL = "sqlite:///./campus_news.db"

# 创建数据库引擎
# echo=True 会在控制台打印所有 SQL 语句，方便调试
engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},  # SQLite 多线程适配
    echo=False,  # 设为 True 可查看所有 SQL 执行日志
)

# 创建会话工厂
# autocommit=False: 需要手动 commit，保证数据一致性
# autoflush=False: 手动控制刷新时机
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# ORM 基类，所有模型类继承自此
Base = declarative_base()


def get_db():
    """
    数据库会话依赖注入函数
    ----------------------
    用于 FastAPI 路由中，通过 Depends(get_db) 获取数据库会话。
    每个请求自动获取一个新会话，请求结束后自动关闭，
    确保数据库连接不泄漏。

    使用示例：
        @app.get("/news")
        def get_news(db: Session = Depends(get_db)):
            ...
    """
    db = SessionLocal()  # 为当前请求创建独立会话
    try:
        yield db  # 将会话传递给路由函数
    finally:
        db.close()  # 请求处理完毕后关闭会话，归还连接
