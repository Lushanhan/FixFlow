"""
数据存储模块
===========
将处理完成的 PageInfo 数据写入数据库 news 表。
本模块是数据从"外部网页"到"本地数据库"的最后一步。

存储流程：
  PageInfo → 遍历 news_items → 创建 News 记录 → commit
"""

import logging
from datetime import datetime

from sqlalchemy.orm import Session

from .models import News
from .html_processor import PageInfo, NewsItem

logger = logging.getLogger("storage")


def save_page_info(page_info: PageInfo, db: Session) -> int:
    """
    将处理完成的页面数据存入数据库
    ------------------------------
    遍历 PageInfo 中的每一条 NewsItem，创建对应的 News 记录。
    已存在相同 label + title 的记录会跳过，避免重复入库。

    参数:
        page_info: HTML 处理器输出的页面解析结果
        db:        数据库会话

    返回:
        本次成功存入的新闻条数
    """
    saved_count = 0

    for item in page_info.news_items:
        # ----- 跳过空标题 -----
        if not item.title.strip():
            logger.warning("跳过空标题条目")
            continue

        # ----- 去重检查：同标签 + 同标题视为重复 -----
        existing = (
            db.query(News)
            .filter(News.label == page_info.unique_label, News.title == item.title)
            .first()
        )
        if existing:
            logger.info(f"跳过重复新闻: '{item.title[:30]}...' (label: {page_info.unique_label})")
            continue

        # ----- 创建新闻记录 -----
        news = News(
            title=item.title,
            content=item.content,                       # 清洗后的正文 HTML
            label=page_info.unique_label,               # 独立标签 "1001_2026.7.7"
            source=page_info.university_name,           # 来源：大学名称
            source_url=item.link,                       # 详情页链接
            publish_time=datetime.utcnow(),             # 发布时间（后续从详情页提取）
            is_published=True,
        )
        db.add(news)
        saved_count += 1
        logger.info(
            f"新闻入库: '{item.title[:30]}...' "
            f"→ label: {page_info.unique_label}"
        )

    # ----- 批量提交 -----
    if saved_count > 0:
        db.commit()
        logger.info(f"本次共存入 {saved_count} 条新闻")

    return saved_count
