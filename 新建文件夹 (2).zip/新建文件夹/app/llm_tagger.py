
"""
LLM 自动打标模块

===============
将数据库中预存的编码标签映射表作为 system prompt，
调用外部 LLM API，根据新闻标题自动返回匹配的标签编码。
返回的编码追加到新闻唯一标识后方。

使用流程：
  1. 从 tags 表读取所有标签 → 构建映射表 system prompt
  2. 将新闻标题传给 LLM → LLM 返回匹配的编码列表
  3. 编码追加到 label 后方 → "1001_2026.7.7_01_03"
"""

import os
import json
import logging
from typing import List, Optional

import httpx
from sqlalchemy.orm import Session

from .models import Tag

logger = logging.getLogger("llm_tagger")

# ============================================================
# LLM API 默认配置（可通过参数或环境变量覆盖）
# ============================================================
DEFAULT_API_URL = os.getenv("LLM_API_URL", "https://api.deepseek.com/v1/chat/completions")
DEFAULT_MODEL = os.getenv("LLM_MODEL", "deepseek-chat")


# ============================================================
# LLMTagger —— LLM 打标器
# ============================================================
class LLMTagger:
    """
    LLM 自动打标器
    -------------
    读取数据库标签映射表，构建 system prompt，
    调用 LLM API 根据新闻标题返回匹配的标签编码。

    使用示例：
        tagger = LLMTagger(db)
        codes = await tagger.tag_news("关于奖学金评选结果的通知")
        # codes = ["03", "04", "10"]
    """

    def __init__(
        self,
        db: Session,
        api_key: str = "",
        api_url: str = "",
        model: str = "",
    ):
        """
        初始化打标器
        ------------
        参数:
            db:      数据库会话，用于读取 tags 表
            api_key: DeepSeek API 密钥（优先使用此参数，为空时从环境变量 LLM_API_KEY 读取）
            api_url: API 地址（可选，默认 DeepSeek 官方地址）
            model:   模型名称（可选，默认 deepseek-chat）
        """
        self.db = db
        self.api_key = api_key or os.getenv("LLM_API_KEY", "")
        self.api_url = api_url or DEFAULT_API_URL
        self.model = model or DEFAULT_MODEL
        self._tag_mapping: Optional[str] = None

    # ========================================================
    # 构建映射表（system prompt）
    # ========================================================
    def build_tag_mapping(self) -> str:
        """
        从数据库 tags 表读取所有标签，构建编码映射表
        ------------------------------------------
        格式：
          编码 | 标签名称
          -----|---------
          00   | 学术科研
          01   | 学科竞赛
          ...

        返回:
            编码映射表文本，用作 LLM system prompt
        """
        tags = self.db.query(Tag).order_by(Tag.code).all()
        lines = ["编码 | 标签名称", "-----|---------"]
        for tag in tags:
            lines.append(f"{tag.code}   | {tag.name}")
        self._tag_mapping = "\n".join(lines)
        logger.info(f"标签映射表已构建，共 {len(tags)} 个标签")
        return self._tag_mapping

    # ========================================================
    # 构建 system prompt
    # ========================================================
    def _build_system_prompt(self) -> str:
        """构建完整的 system prompt"""
        if not self._tag_mapping:
            self.build_tag_mapping()

        return (
            "你是一个新闻分类助手。下面是一张标签编码映射表：\n"
            f"{self._tag_mapping}\n\n"
            "规则：\n"
            "1. 根据新闻标题，尽可能多地选择匹配的标签编码\n"
            "2. 只返回标签编码，多个编码之间用逗号分隔\n"
            "3. 只返回存在的编码，不要编造新编码\n"
            "4. 输出格式示例：03,04,10\n"
            "5. 如果没有任何标签匹配，返回空"
        )

    # ========================================================
    # 调用 LLM API
    # ========================================================
    async def tag_news(self, title: str) -> List[str]:
        """
        根据新闻标题调用 LLM 获取匹配的标签编码
        --------------------------------------
        参数:
            title: 新闻标题文本
        返回:
            匹配的标签编码列表，如 ["03", "04", "10"]
        """
        if not title.strip():
            return []

        system_prompt = self._build_system_prompt()

        # 构建 API 请求体
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"请为以下新闻标题打三个标签：\n\n{title}，仅从小到大输出对应的序号"},
            ],
            "temperature": 0.1,  # 低温度，提高输出稳定性
            "max_tokens": 50,
        }

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.post(
                    self.api_url,
                    json=payload,
                    headers=headers,
                )
                response.raise_for_status()
                data = response.json()

                # 解析 LLM 返回的编码
                raw = data["choices"][0]["message"]["content"].strip()
                codes = self._parse_codes(raw)
                logger.info(
                    f"LLM 打标完成: '{title[:30]}...' → 编码 {codes}"
                )
                return codes

        except httpx.TimeoutException:
            logger.error(f"LLM API 超时: '{title[:30]}...'")
            return []
        except Exception as exc:
            logger.error(f"LLM API 异常: {exc}")
            return []

    # ========================================================
    # 解析 LLM 返回的编码字符串
    # ========================================================
    @staticmethod
    def _parse_codes(raw: str) -> List[str]:
        """
        解析 LLM 返回的编码字符串
        -------------------------
        LLM 返回格式如 "03,04,10" 或 "03 04 10"，
        解析为编码列表，只保留合法的两位数字编码。

        参数:
            raw: LLM 返回的原始文本
        返回:
            合法的编码列表（00~99）
        """
        import re
        # 提取所有两位数字
        matches = re.findall(r'\b(\d{2})\b', raw)
        # 去重并保持 LLM 返回的顺序
        seen = set()
        codes = []
        for code in matches:
            if code not in seen:
                seen.add(code)
                codes.append(code)
        return codes

    # ========================================================
    # 将编码追加到唯一标识
    # ========================================================
    @staticmethod
    def extend_label(base_label: str, codes: List[str]) -> str:
        """
        将标签编码追加到唯一标识后方
        ----------------------------
        参数:
            base_label: 基础唯一标识，如 "1001_2026.7.7"
            codes:      标签编码列表，如 ["03", "04"]
        返回:
            扩展后的标识，如 "1001_2026.7.7_03_04"
        """
        if not codes:
            return base_label
        suffix = "_".join(codes)
        return f"{base_label}_{suffix}"
