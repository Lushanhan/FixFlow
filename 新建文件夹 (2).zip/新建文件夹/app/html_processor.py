"""
新闻网页内容处理模块
===================
独立于爬虫模块，负责解析爬虫获取的 HTML 页面内容。
按照模板规则提取大学名称、日期等信息，匹配数据库映射表，
合成每条新闻的唯一独立标签。

处理流程：
  1. 从 <title> 和 <meta> 中提取大学名称
  2. 匹配 universities 表获取数字编码
  3. 从 <div class="header-date"> 提取日期 → 格式化为 YYYY.M.D
  4. 编码 + 日期 合成独立标签（如 "1001_2026.7.7"）
  5. 从 <article class="news-item"> 提取标题和详情链接
  6. 处理详情页 → 清洗 HTML → 存入 content 字段
"""

import re
import logging
from datetime import datetime
from dataclasses import dataclass, field
from typing import Optional, List

from bs4 import BeautifulSoup
from sqlalchemy.orm import Session

from .models import University

logger = logging.getLogger("html_processor")


# ============================================================
# NewsItem —— 单条新闻条目
# ============================================================
# 清洗 HTML 时保留的标签白名单
KEEP_TAGS = {"p", "img", "strong", "b", "em", "i", "u", "h1", "h2", "h3",
             "h4", "h5", "h6", "ul", "ol", "li", "blockquote", "a",
             "br", "figure", "figcaption", "table", "tr", "td", "th", "thead", "tbody"}

# <img> 标签保留的属性
KEEP_ATTRS = {"src", "alt"}


@dataclass
class NewsItem:
    """
    单条新闻条目
    ------------
    每条新闻隶属一个独立标签（unique_label）之下，
    包含标题、正文链接和清洗后的正文内容。
    """
    title: str = ""     # 新闻标题
    link: str = ""      # 新闻详情页链接
    content: str = ""   # 清洗后的正文 HTML（含图片），待处理详情页后填充


# ============================================================
# PageInfo —— 页面解析结果
# ============================================================
@dataclass
class PageInfo:
    """
    单个页面的解析结果
    ------------------
    university_name: 从页面中提取的大学名称
    university_code: 匹配数据库得到的数字编码
    page_date:       页面日期（raw）
    formatted_date:  格式化后的日期（YYYY.M.D）
    unique_label:    独立标签 = 编码_日期（如 "1001_2026.7.7"）
    news_items:      页面中的新闻条目列表，每个条目含标题和正文
    """
    university_name: str = ""
    university_code: int = 0
    source_tag: str = ""                # 来源分组标签 A/B，由爬虫传入
    page_date: str = ""
    formatted_date: str = ""
    unique_label: str = ""              # 独立标签，如 "1001_2026.7.7_A"
    news_items: List[NewsItem] = field(default_factory=list)


# ============================================================
# NewsPageProcessor —— 页面处理器
# ============================================================
class NewsPageProcessor:
    """
    新闻页面 HTML 内容处理器
    ------------------------
    接收爬虫获取的 HTML，按模板规则解析并提取结构化信息。
    需要数据库会话来匹配大学名称→编码映射。

    使用示例：
        processor = NewsPageProcessor(db_session)
        page_info = processor.process(html_text)
        print(page_info.unique_label)  # "1001_2026.7.7"
    """

    def __init__(self, db: Session):
        """
        初始化处理器
        ------------
        参数:
            db: SQLAlchemy 数据库会话，用于查询 universities 映射表
        """
        self.db = db

    # ========================================================
    # 步骤1：提取大学名称
    # ========================================================
    def _extract_university_name(self, soup: BeautifulSoup) -> str:
        """
        从 <title> 和 <meta description> 中提取大学名称
        -----------------------------------------------
        模板格式：
          <title>校园新闻 - **某某大学**新闻网</title>
          <meta name="description" content="**某某大学**校园新闻聚合平台">

        提取规则：
          1. 优先从 <title> 中提取 "校园新闻 - " 和 "新闻网" 之间的文本
          2. 若失败，从 <meta name="description"> 的 content 属性中提取
             "校园新闻聚合平台" 之前的文本

        返回:
            大学名称字符串（输入字段默认保证合法）
        """
        # ----- 方式1：从 <title> 提取 -----
        title_tag = soup.find("title")
        if title_tag and title_tag.string:
            title_text = title_tag.string.strip()
            # 模板："校园新闻 - XXXX大学新闻网"
            # 提取 "- " 之后、"新闻网" 之前的部分
            match = re.search(r'校园新闻\s*[-—]\s*(.+?)新闻网', title_text)
            if match:
                name = match.group(1).strip()
                logger.info(f"从 <title> 提取大学名称: '{name}'")
                return name

        # ----- 方式2：从 <meta name="description"> 提取 -----
        meta_desc = soup.find("meta", attrs={"name": "description"})
        if meta_desc and meta_desc.get("content"):
            content = meta_desc["content"].strip()
            # 模板："XXXX大学校园新闻聚合平台"
            # 提取 "校园新闻聚合平台" 之前的部分
            match = re.search(r'(.+?)校园新闻聚合平台', content)
            if match:
                name = match.group(1).strip()
                logger.info(f"从 <meta description> 提取大学名称: '{name}'")
                return name

        # 若都未匹配（理论上不会发生，输入默认合法）
        logger.warning("未能从页面中提取大学名称")
        return ""

    # ========================================================
    # 步骤2：匹配数据库映射表
    # ========================================================
    def _match_university_code(self, university_name: str) -> int:
        """
        根据大学名称查询 universities 表，获取对应数字编码
        ------------------------------------------------
        参数:
            university_name: 从页面提取的大学名称
        返回:
            对应的数字编码（一一映射，输入默认合法，必定命中）
        """
        # 查询数据库中的大学映射记录
        university = (
            self.db.query(University)
            .filter(University.name == university_name)
            .first()
        )
        if university:
            logger.info(
                f"大学映射命中: '{university_name}' → 编码 {university.code}"
            )
            return university.code
        else:
            # 输入默认合法，此分支为防御性处理
            logger.error(f"大学名称 '{university_name}' 在数据库中无映射记录")
            return 0

    # ========================================================
    # 步骤3：提取并格式化日期
    # ========================================================
    def _extract_and_format_date(self, soup: BeautifulSoup) -> tuple:
        """
        从 <div class="header-date"> 中提取日期并格式化
        -----------------------------------------------
        模板格式：
          <div class="header-date">2026年7月7日 星期二</div>

        返回:
            (原始日期文本, 格式化日期)
            如 ("2026年7月7日", "2026.7.7")
        """
        date_div = soup.find("div", class_="header-date")
        if date_div and date_div.string:
            raw_text = date_div.string.strip()
            # 解析 "2026年7月7日 星期二" → (2026, 7, 7)
            match = re.search(r'(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日', raw_text)
            if match:
                year, month, day = match.group(1), match.group(2), match.group(3)
                # 去前导零：月日直接转 int 再格式化
                formatted = f"{year}.{int(month)}.{int(day)}"
                logger.info(f"日期提取: '{raw_text}' → '{formatted}'")
                return raw_text, formatted

        logger.warning("未能从页面中提取日期")
        return "", ""

    # ========================================================
    # 步骤4：合成独立标签
    # ========================================================
    def _build_unique_label(self, university_code: int, formatted_date: str, source_tag: str) -> str:
        """
        将大学编码、日期和来源标签合成为独立标签
        ----------------------------------------
        格式：{编码}_{日期}_{来源标签}
        示例：1001_2026.7.7_A

        参数:
            university_code: 大学数字编码
            formatted_date:  格式化日期（YYYY.M.D）
            source_tag:      来源分组标签（A/B）
        返回:
            独立标签字符串
        """
        label = f"{university_code}_{formatted_date}_{source_tag}" if source_tag else f"{university_code}_{formatted_date}"
        logger.info(f"独立标签合成: '{label}'")
        return label

    # ========================================================
    # 步骤5：提取新闻标题（正文后续处理）
    # ========================================================
    def _extract_news_items(self, soup: BeautifulSoup) -> List[NewsItem]:
        """
        从页面中提取所有新闻条目，每条包含标题、链接和正文
        ------------------------------------------------
        HTML 模板结构：
          <article class="news-item">
              <h3 class="news-title">
                  <a href="/news/2026/0706/002.html">新闻标题文本</a>
              </h3>
          </article>

        提取标题文本和详情页链接，正文字段待处理详情页后填充。

        返回:
            NewsItem 列表
        """
        items = []
        articles = soup.find_all("article", class_="news-item")
        for article in articles:
            # ----- 提取标题和链接 -----
            title_tag = article.find("h3", class_="news-title")
            title = ""
            link = ""
            if title_tag:
                a_tag = title_tag.find("a")
                if a_tag:
                    title = a_tag.get_text(strip=True)
                    link = a_tag.get("href", "")
                else:
                    title = title_tag.get_text(strip=True)

            items.append(NewsItem(title=title, link=link, content=""))
            log_title = title[:40] + "..." if len(title) > 40 else title
            logger.info(f"新闻标题提取: '{log_title}' | 链接: {link}")

        logger.info(f"共提取 {len(items)} 条新闻标题")
        return items

    # ========================================================
    # 步骤6：清洗 HTML —— 去掉样式保留结构与图片
    # ========================================================
    @staticmethod
    def clean_html(raw_html: str) -> str:
        """
        清洗原始 HTML，去掉样式和脚本，保留内容结构与图片
        ------------------------------------------------
        清洗规则：
        - 移除 <script>、<style>、<noscript>、<iframe>
        - 移除所有标签的 class、style、id、data-* 等属性
        - 保留 <img> 的 src 和 alt 属性
        - 只保留结构标签（p, h1-h6, ul, ol, li, blockquote,
          strong, b, em, i, br, figure, figcaption, a, table 等）
        - 其他标签去除但保留内部文本

        参数:
            raw_html: 原始 HTML 字符串
        返回:
            清洗后的 HTML 字符串，不同来源清洗后结构统一
        """
        soup = BeautifulSoup(raw_html, "lxml")

        # ----- 1. 移除危险/无用标签 -----
        for tag_name in ["script", "style", "noscript", "iframe", "comment"]:
            for tag in soup.find_all(tag_name):
                tag.decompose()

        # ----- 2. 遍历所有标签，清洗属性 / 移除非结构标签 -----
        for tag in soup.find_all():
            # ---- 移除所有属性，仅保留 img 的 src 和 alt ----
            if tag.name == "img":
                src = tag.get("src", "")
                alt = tag.get("alt", "")
                tag.attrs.clear()
                if src:
                    tag["src"] = src
                if alt:
                    tag["alt"] = alt
            elif tag.name == "a":
                href = tag.get("href", "")
                tag.attrs.clear()
                if href:
                    tag["href"] = href
            else:
                tag.attrs.clear()

            # ---- 非白名单标签：unwarp（移除标签保留内部文本） ----
            if tag.name not in KEEP_TAGS:
                tag.unwrap()

        # ----- 3. 提取 body 内的清洗结果 -----
        body = soup.find("body")
        if body:
            cleaned = "".join(str(child) for child in body.children).strip()
        else:
            cleaned = str(soup).strip()

        logger.info(f"HTML 清洗完成: {len(raw_html)} → {len(cleaned)} 字符")
        return cleaned

    # ========================================================
    # 步骤7：处理详情页，提取正文内容
    # ========================================================
    def process_detail_page(self, html: str) -> str:
        """
        处理新闻详情页，提取并清洗正文内容
        ----------------------------------
        从详情页中找到正文区域（<div class="article-content">
        或 <article>），提取全部内容（文字+图片），
        清洗 HTML 后返回。

        参数:
            html: 详情页完整 HTML 文本
        返回:
            清洗后的正文 HTML 字符串
        """
        soup = BeautifulSoup(html, "lxml")

        # ----- 定位正文区域 -----
        content_div = soup.find("div", class_="article-content")
        if content_div:
            raw_content = str(content_div)
        else:
            # 备选：查找 <article> 标签
            article_tag = soup.find("article")
            if article_tag:
                raw_content = str(article_tag)
            else:
                # 最后备选：整个 body
                body = soup.find("body")
                raw_content = str(body) if body else html

        # ----- 清洗 -----
        cleaned = self.clean_html(raw_content)
        logger.info(f"详情页正文提取完成: {len(cleaned)} 字符")
        return cleaned

    # ========================================================
    # 主处理入口
    # ========================================================
    def process(self, html: str, source_tag: str = "") -> PageInfo:
        """
        处理爬虫获取的 HTML 页面内容
        ----------------------------
        按顺序执行 提取大学名称 → 匹配编码 → 提取日期 → 合成标签。

        参数:
            html:       完整的网页 HTML 文本
            source_tag: 来源分组标签（A=学校官网, B=公众号），由爬虫传入
        返回:
            PageInfo 实例，包含解析后的所有信息
        """
        soup = BeautifulSoup(html, "lxml")

        # 步骤1：提取大学名称
        university_name = self._extract_university_name(soup)

        # 步骤2：匹配数据库映射表获取编码
        university_code = self._match_university_code(university_name)

        # 步骤3：提取日期并格式化
        page_date, formatted_date = self._extract_and_format_date(soup)

        # 步骤4：合成独立标签（含来源标签）
        unique_label = self._build_unique_label(university_code, formatted_date, source_tag)

        # 步骤5：提取新闻标题（正文后续处理）
        news_items = self._extract_news_items(soup)

        return PageInfo(
            university_name=university_name,
            university_code=university_code,
            source_tag=source_tag,
            page_date=page_date,
            formatted_date=formatted_date,
            unique_label=unique_label,
            news_items=news_items,
        )
