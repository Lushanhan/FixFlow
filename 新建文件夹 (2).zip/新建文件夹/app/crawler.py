"""
新闻爬虫模块
===========
负责从外部指定的网址定时抓取网页 HTML 内容。
- 抓取目标网址和抓取间隔由外部配置控制
- 获取网页信息后的处理逻辑由外部回调函数定义
- 本模块只负责"获取"，不负责"解析"和"存储"
"""

import asyncio
import logging
from typing import List, Callable, Optional, Dict
from dataclasses import dataclass, field

import httpx

# ============================================================
# 日志
# ============================================================
logger = logging.getLogger("crawler")


# ============================================================
# CrawlConfig —— 爬虫配置（外部可设置）
# ============================================================
@dataclass
class CrawlConfig:
    """
    爬虫配置数据类
    --------------
    所有字段均可从外部传入（配置文件、环境变量、API 等），
    实现网址和抓取间隔的外部可设置。

    字段说明：
        urls:       要抓取的目标网址列表
        interval:   抓取间隔（秒），每隔 interval 秒对 urls 全部抓取一轮
        timeout:    单次 HTTP 请求超时时间（秒）
        headers:    自定义请求头（模拟浏览器，避免被反爬）
        max_retries: 单次请求失败后的最大重试次数
    """
    urls: List[str] = field(default_factory=list)
    interval: int = 3600                     # 默认每小时抓取一次
    timeout: int = 30                        # 默认请求超时 30 秒
    headers: Dict[str, str] = field(default_factory=lambda: {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9",
    })
    max_retries: int = 2


# ============================================================
# CrawlResult —— 单次抓取结果
# ============================================================
@dataclass
class CrawlResult:
    """
    单次抓取的结果
    --------------
    url:        请求的网址
    html:       获取到的网页 HTML 文本（成功时）
    status_code: HTTP 状态码
    error:      错误信息（失败时）
    success:    是否成功
    """
    url: str
    html: str = ""
    status_code: int = 0
    error: str = ""
    success: bool = False


# ============================================================
# NewsCrawler —— 爬虫主类
# ============================================================
class NewsCrawler:
    """
    新闻网页爬虫
    -----------
    负责按照配置定时抓取指定网址的 HTML 内容。
    网页信息的具体解析和处理由外部回调函数完成（后续定义）。

    使用示例：
        config = CrawlConfig(
            urls=["https://example.com/news"],
            interval=1800,  # 30分钟
        )
        crawler = NewsCrawler(config)
        crawler.on_fetch = my_process_func  # 设置处理回调
        await crawler.start()
    """

    def __init__(self, config: CrawlConfig):
        """
        初始化爬虫
        ----------
        参数:
            config: CrawlConfig 实例，包含网址、间隔等外部配置
        """
        self.config = config
        self._running = False
        self._task: Optional[asyncio.Task] = None
        # ---- 处理回调 ----
        # 获取到网页 HTML 后调用的回调函数，
        # 签名为: async def callback(result: CrawlResult) -> None
        # 由外部设置，实现"获取"与"处理"的解耦
        self.on_fetch: Optional[Callable[[CrawlResult], None]] = None

    # ========================================================
    # 更新配置（外部运行时修改网址和间隔）
    # ========================================================
    def update_config(self, urls: List[str] = None, interval: int = None):
        """
        在运行时更新爬虫配置
        --------------------
        允许外部随时修改抓取网址和抓取间隔，无需重启。
        参数:
            urls:     新的目标网址列表（None 表示不修改）
            interval: 新的抓取间隔秒数（None 表示不修改）
        """
        if urls is not None:
            self.config.urls = urls
            logger.info(f"爬虫网址已更新，目标数: {len(urls)}")
        if interval is not None:
            self.config.interval = interval
            logger.info(f"爬虫间隔已更新: {interval}秒")

    # ========================================================
    # 单次抓取
    # ========================================================
    async def fetch_page(self, url: str) -> CrawlResult:
        """
        抓取单个网址的网页内容
        ----------------------
        参数:
            url: 目标网页地址
        返回:
            CrawlResult 实例，包含 HTML 文本或错误信息
        """
        last_error = ""
        for attempt in range(1, self.config.max_retries + 2):  # +2 因为首次+重试
            try:
                async with httpx.AsyncClient(timeout=self.config.timeout) as client:
                    response = await client.get(url, headers=self.config.headers)
                    result = CrawlResult(
                        url=url,
                        html=response.text,
                        status_code=response.status_code,
                        success=True,
                    )
                    logger.info(
                        f"[{url}] 抓取成功 "
                        f"(状态码: {response.status_code}, "
                        f"内容长度: {len(response.text)} 字符)"
                    )
                    return result
            except httpx.TimeoutException:
                last_error = f"请求超时（{self.config.timeout}秒）"
                logger.warning(f"[{url}] {last_error}，第{attempt}次尝试")
            except httpx.HTTPStatusError as exc:
                last_error = f"HTTP 错误: {exc.response.status_code}"
                logger.warning(f"[{url}] {last_error}，第{attempt}次尝试")
            except Exception as exc:
                last_error = f"未知错误: {type(exc).__name__}: {exc}"
                logger.warning(f"[{url}] {last_error}，第{attempt}次尝试")
            # 重试前等待
            if attempt <= self.config.max_retries:
                await asyncio.sleep(2 ** attempt)  # 指数退避

        # 所有重试均失败
        return CrawlResult(url=url, error=last_error, success=False)

    # ========================================================
    # 一轮抓取（遍历所有 URL）
    # ========================================================
    async def _crawl_round(self):
        """
        执行一轮完整抓取：依次抓取配置中的所有 URL
        ------------------------------------------
        每抓取一个 URL 后间隔 1 秒（避免对同一服务器造成压力），
        不在 URL 之间使用配置的 interval（interval 是轮之间的间隔）。
        """
        logger.info(f"开始新一轮抓取，共 {len(self.config.urls)} 个目标")
        for index, url in enumerate(self.config.urls):
            if not self._running:
                break
            result = await self.fetch_page(url)
            # ---- 调用外部处理回调 ----
            # 网页信息的具体解析和存储由外部定义的回调完成
            if self.on_fetch and result.success:
                try:
                    if asyncio.iscoroutinefunction(self.on_fetch):
                        await self.on_fetch(result)
                    else:
                        self.on_fetch(result)
                except Exception as exc:
                    logger.error(f"处理回调异常 [{url}]: {exc}")
            # URL 之间的间隔（避免请求过于密集）
            if index < len(self.config.urls) - 1:
                await asyncio.sleep(1)

    # ========================================================
    # 启动/停止
    # ========================================================
    async def _run_loop(self):
        """爬虫主循环：按 interval 间隔重复执行抓取轮次"""
        logger.info(
            f"爬虫已启动，目标: {len(self.config.urls)} 个网址，"
            f"间隔: {self.config.interval} 秒"
        )
        while self._running:
            await self._crawl_round()
            if self._running:
                logger.info(f"本轮完成，等待 {self.config.interval} 秒后开始下一轮...")
                await asyncio.sleep(self.config.interval)

    async def start(self):
        """
        启动爬虫（后台运行）
        ------------------
        调用后爬虫开始按间隔定时抓取，不会阻塞当前线程。
        可通过 stop() 停止，通过 update_config() 在运行时修改配置。
        """
        if self._running:
            logger.warning("爬虫已在运行中")
            return
        self._running = True
        self._task = asyncio.create_task(self._run_loop())

    async def stop(self):
        """
        停止爬虫
        -------
        等待当前正在执行的请求完成，然后停止循环。
        """
        if not self._running:
            return
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("爬虫已停止")

    # ========================================================
    # 单次手动抓取（无需启动循环）
    # ========================================================
    async def fetch_once(self) -> List[CrawlResult]:
        """
        手动触发一次完整抓取（不依赖定时循环）
        ------------------------------------
        用于外部主动触发抓取（如 API 端点调用），
        立即对所有配置的 URL 抓取一轮并返回结果。
        返回:
            所有 URL 的抓取结果列表
        """
        results = []
        for url in self.config.urls:
            result = await self.fetch_page(url)
            results.append(result)
            if self.on_fetch and result.success:
                try:
                    if asyncio.iscoroutinefunction(self.on_fetch):
                        await self.on_fetch(result)
                    else:
                        self.on_fetch(result)
                except Exception as exc:
                    logger.error(f"处理回调异常 [{url}]: {exc}")
        return results
