"""
数据库初始化与种子数据模块
=======================
负责：
1. 首次启动时自动创建所有数据表
2. 插入预设的编码标签和默认管理员账号
3. 种子数据仅在对应表为空时才插入，避免重复
"""

from passlib.context import CryptContext

from .database import engine, SessionLocal, Base
from .models import User, Tag, University, SourceGroup  # 导入所有模型，确保 Base.metadata 包含全部表

# ============================================================
# 密码哈希工具
# passlib 的 bcrypt 算法用于密码的加盐哈希，
# 数据库只存储哈希值，不存储明文密码
# ============================================================
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    """
    对明文密码进行 bcrypt 哈希处理
    ------------------------------
    参数:
        password: 明文密码
    返回:
        哈希后的密码字符串，存入数据库 password_hash 字段
    """
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    验证明文密码是否匹配哈希值
    --------------------------
    参数:
        plain_password: 用户输入的明文密码
        hashed_password: 数据库中存储的哈希密码
    返回:
        True 表示密码正确，False 表示密码错误
    """
    return pwd_context.verify(plain_password, hashed_password)


# ============================================================
# 种子数据
# ============================================================

# 预设编码标签 —— 编码范围 00~99，作为 LLM system prompt 的映射表
# LLM 根据新闻标题返回匹配的标签编码，编码追加到新闻唯一标识后方
DEFAULT_TAGS = [
    {"code": "00", "name": "学术科研"},
    {"code": "01", "name": "学科竞赛"},
    {"code": "02", "name": "学术讲座"},
    {"code": "03", "name": "奖学金"},
    {"code": "04", "name": "评优评先"},
    {"code": "05", "name": "校园活动"},
    {"code": "06", "name": "文艺演出"},
    {"code": "07", "name": "社团活动"},
    {"code": "08", "name": "运动会"},
    {"code": "09", "name": "志愿服务"},
    {"code": "10", "name": "通知公告"},
    {"code": "11", "name": "考试通知"},
    {"code": "12", "name": "教务安排"},
    {"code": "13", "name": "招生信息"},
    {"code": "14", "name": "毕业就业"},
    {"code": "15", "name": "创业创新"},
    {"code": "16", "name": "企业招聘"},
    {"code": "17", "name": "校友动态"},
    {"code": "18", "name": "国际交流"},
    {"code": "19", "name": "党建思政"},
]

# 预设来源分组 —— A=学校官网，B=公众号
# 爬虫根据网址所属分组，在唯一标识中追加对应标签
DEFAULT_SOURCE_GROUPS = [
    {"name": "学校官网", "tag": "A"},
    {"name": "公众号", "tag": "B"},
]

# 默认管理员账号（预设格式：admin + 密码）
# 生产环境中应立即修改此密码
DEFAULT_ADMIN = {
    "username": "admin",
    "password": "admin123456",  # 明文密码，存入数据库前会经过 hash 处理
    "role": "admin",
}


def init_database():
    """
    数据库初始化入口函数
    --------------------
    在 FastAPI 应用启动时调用一次。
    执行顺序：
    1. 创建所有表（如果不存在）
    2. 插入种子标签数据（如果表为空）
    3. 插入来源分组数据（如果表为空）
    4. 创建默认管理员账号（如果不存在）
    """
    # ----- 步骤1：创建所有数据表 -----
    # Base.metadata.create_all 会检查所有继承自 Base 的模型类，
    # 并自动在数据库中创建对应的表（已存在的表会跳过）
    Base.metadata.create_all(bind=engine)

    # ----- 步骤2：开启数据库会话，插入种子数据 -----
    db = SessionLocal()
    try:
        # ----- 初始化编码标签数据 -----
        if db.query(Tag).count() == 0:
            for tag in DEFAULT_TAGS:
                db.add(Tag(**tag))
            db.commit()

        # ----- 初始化来源分组数据 -----
        if db.query(SourceGroup).count() == 0:
            for group in DEFAULT_SOURCE_GROUPS:
                db.add(SourceGroup(**group))
            db.commit()

        # ----- 初始化默认管理员账号 -----
        if db.query(User).filter(User.username == DEFAULT_ADMIN["username"]).count() == 0:
            admin_user = User(
                username=DEFAULT_ADMIN["username"],
                password_hash=hash_password(DEFAULT_ADMIN["password"]),
                role=DEFAULT_ADMIN["role"],
            )
            db.add(admin_user)
            db.commit()

    finally:
        db.close()  # 确保会话关闭，归还数据库连接
