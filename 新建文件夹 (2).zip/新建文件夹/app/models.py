"""
数据库模型定义模块
=================
定义所有数据表的 ORM 模型。每张表都是一个 Python 类，
继承自 Base（SQLAlchemy ORM 基类）。
新增数据类型只需在此文件中添加新的模型类即可。

数据表概览：
- User         → 用户表（含权限标签 role 字段）
- Tag          → 编码标签表（code 00~99，LLM 自动打标用）
- News         → 新闻内容表
- news_tags    → 新闻-标签关联表（多对多）
- University   → 大学名称与数字编码映射表
- SourceGroup  → 来源分组表（A=学校官网，B=公众号）
- SourceUrl    → 分组下属网址表

唯一标识格式：
  {大学编码}_{日期}_{来源标签A/B}_{LLM标签编码...}
  示例：1001_2026.7.7_A_03_04
"""

from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Text, DateTime, Boolean, ForeignKey, Table
)
from sqlalchemy.orm import relationship

from .database import Base  # 从统一入口导入 ORM 基类


# ============================================================
# 新闻-标签关联表（多对多中间表）
# 一条新闻可以有多个标签，一个标签也可对应多条新闻
# 标签由 LLM 根据新闻标题自动分配
# ============================================================
news_tags = Table(
    "news_tags",
    Base.metadata,
    Column("news_id", Integer, ForeignKey("news.id", ondelete="CASCADE"), primary_key=True),
    Column("tag_id", Integer, ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True),
)


# ============================================================
# User —— 用户表
# 记录所有可登录用户的信息，通过 role 字段区分普通用户和管理员
# ============================================================
class User(Base):
    __tablename__ = "users"

    # --- 主键 ---
    id = Column(Integer, primary_key=True, autoincrement=True, comment="用户唯一ID")

    # --- 登录凭证 ---
    username = Column(
        String(50), unique=True, nullable=False, index=True,
        comment="登录用户名，必须唯一"
    )
    password_hash = Column(
        String(255), nullable=False,
        comment="密码哈希值，不存储明文密码"
    )

    # --- 权限标签 ---
    # role 字段用于区分用户权限：'user' 为普通用户，'admin' 为管理员
    # 后续可通过此字段实现 RBAC 权限控制
    role = Column(
        String(20), nullable=False, default="user",
        comment="用户角色标签：user（普通用户）/ admin（管理员）"
    )

    # --- 状态与时间 ---
    is_active = Column(
        Boolean, default=True,
        comment="账户是否激活，False 表示已禁用"
    )
    created_at = Column(
        DateTime, default=datetime.utcnow,
        comment="账户创建时间"
    )

    def __repr__(self):
        return f"<User(id={self.id}, username='{self.username}', role='{self.role}')>"


# ============================================================
# Tag —— 编码标签表
# 预存标签名称与两位数字编码（00~99）的映射。
# 所有标签编码组成 LLM 的 system prompt 映射表，
# LLM 根据新闻标题返回匹配的标签编码。
# ============================================================
class Tag(Base):
    __tablename__ = "tags"

    # --- 主键 ---
    id = Column(Integer, primary_key=True, autoincrement=True, comment="标签唯一ID")

    # --- 标签信息 ---
    name = Column(
        String(50), unique=True, nullable=False,
        comment="标签名称，如：奖学金、运动会、考试、招新"
    )
    code = Column(
        String(2), unique=True, nullable=False,
        comment="两位数字编码（00~99），与标签名称一一映射"
    )

    # --- 反向关联：获取使用该标签的所有新闻 ---
    news_list = relationship("News", secondary=news_tags, back_populates="tags", lazy="dynamic")

    def __repr__(self):
        return f"<Tag(id={self.id}, code='{self.code}', name='{self.name}')>"


# ============================================================
# News —— 新闻内容表
# 存储校园新闻的完整信息。
# 来源（source）为根标签，tags 为 LLM 自动分配的编码标签。
# 唯一标识格式：{大学编码}_{日期}_{标签编码1}_{标签编码2}_...
# 示例：1001_2026.7.7_01_03_15
# ============================================================
class News(Base):
    __tablename__ = "news"

    # --- 主键 ---
    id = Column(Integer, primary_key=True, autoincrement=True, comment="新闻唯一ID")

    # --- 基本信息 ---
    title = Column(
        String(200), nullable=False,
        comment="新闻标题"
    )
    summary = Column(
        Text, default="",
        comment="新闻摘要/导读，用于列表页展示"
    )
    content = Column(
        Text, nullable=False,
        comment="新闻正文内容，支持长文本"
    )

    # --- 独立标签 ---
    # 由大学编码_日期合成，如 "1001_2026.7.7"，
    # 作为爬虫入库时的唯一批次标记
    label = Column(
        String(50), default="", index=True,
        comment="独立标签（大学编码_日期），用于标记新闻采集批次"
    )

    # --- 来源信息 ---
    source = Column(
        String(100), default="",
        comment='新闻来源，如：校团委、信息学院等'
    )
    source_url = Column(
        String(500), default="",
        comment="原始新闻链接（如有）"
    )
    author = Column(
        String(50), default="",
        comment="作者/发布单位"
    )

    # --- 多对多标签关联 ---
    # 通过 news_tags 中间表关联，标签由 LLM 根据标题自动分配
    tags = relationship(
        "Tag", secondary=news_tags, back_populates="news_list",
        lazy="dynamic",
    )

    # --- 时间字段 ---
    publish_time = Column(
        DateTime, nullable=False,
        comment="新闻原始发布时间"
    )
    created_at = Column(
        DateTime, default=datetime.utcnow,
        comment="新闻录入数据库的时间"
    )
    updated_at = Column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow,
        comment="新闻信息最近一次更新的时间"
    )

    # --- 状态与统计 ---
    is_published = Column(
        Boolean, default=True,
        comment="是否对外发布（False 表示草稿/下架）"
    )
    view_count = Column(
        Integer, default=0,
        comment="浏览次数计数器"
    )

    def __repr__(self):
        return f"<News(id={self.id}, title='{self.title[:30]}...')>"


# ============================================================
# University —— 大学名称与数字编码映射表
# 维护大学名称与唯一数字编码的一一映射关系
# ============================================================
class University(Base):
    __tablename__ = "universities"

    # --- 主键 ---
    id = Column(Integer, primary_key=True, autoincrement=True, comment="自增主键ID")

    # --- 映射字段 ---
    name = Column(
        String(100), unique=True, nullable=False,
        comment="大学完整名称，必须唯一"
    )
    code = Column(
        Integer, unique=True, nullable=False,
        comment="数字编码，与大学名称一一映射，必须唯一"
    )

    def __repr__(self):
        return f"<University(id={self.id}, code={self.code}, name='{self.name}')>"


# ============================================================
# SourceGroup —— 来源分组表
# 维护两个固定子集：学校官网(A) 和 公众号(B)
# 爬虫根据分组标签在唯一标识中追加 A/B
# ============================================================
class SourceGroup(Base):
    __tablename__ = "source_groups"

    id = Column(Integer, primary_key=True, autoincrement=True, comment="分组唯一ID")
    name = Column(
        String(50), unique=True, nullable=False,
        comment="分组名称，如：学校官网、公众号"
    )
    tag = Column(
        String(1), unique=True, nullable=False,
        comment="分组标签，A=学校官网，B=公众号"
    )
    # 反向关联：获取该分组下的所有网址
    urls = relationship("SourceUrl", back_populates="group", lazy="dynamic")

    def __repr__(self):
        return f"<SourceGroup(tag='{self.tag}', name='{self.name}')>"


# ============================================================
# SourceUrl —— 来源网址表
# 每个网址属于一个来源分组，爬虫按分组遍历抓取
# ============================================================
class SourceUrl(Base):
    __tablename__ = "source_urls"

    id = Column(Integer, primary_key=True, autoincrement=True, comment="网址唯一ID")
    group_id = Column(
        Integer, ForeignKey("source_groups.id", ondelete="CASCADE"), nullable=False,
        comment="所属分组ID"
    )
    url = Column(
        String(500), nullable=False,
        comment="新闻列表页完整 URL"
    )
    # 所属分组
    group = relationship("SourceGroup", back_populates="urls")

    def __repr__(self):
        _tag = self.group.tag if self.group else "?"
        return f"<SourceUrl(tag='{_tag}', url='{self.url[:50]}')>"
